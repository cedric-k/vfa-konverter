# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'D:\Cedrics_Dateien\sonstiges\py projects\vfa-convetrer\win\lbl\ui.ui'
#
# Created: Wed Aug 17 20:39:10 2011
#      by: PyQt4 UI code generator 4.8.1
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_Mw(object):
    def setupUi(self, Mw):
        Mw.setObjectName(_fromUtf8("Mw"))
        Mw.resize(508, 381)
        Mw.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.centralwidget = QtGui.QWidget(Mw)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.gridLayout = QtGui.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.txtEingabe = QtGui.QLineEdit(self.centralwidget)
        self.txtEingabe.setEnabled(False)
        self.txtEingabe.setMinimumSize(QtCore.QSize(400, 0))
        self.txtEingabe.setObjectName(_fromUtf8("txtEingabe"))
        self.gridLayout.addWidget(self.txtEingabe, 0, 0, 1, 1)
        self.cmdOeffnen = QtGui.QPushButton(self.centralwidget)
        self.cmdOeffnen.setMaximumSize(QtCore.QSize(90, 16777215))
        self.cmdOeffnen.setObjectName(_fromUtf8("cmdOeffnen"))
        self.gridLayout.addWidget(self.cmdOeffnen, 0, 1, 1, 1)
        self.lblFormat = QtGui.QLabel(self.centralwidget)
        self.lblFormat.setObjectName(_fromUtf8("lblFormat"))
        self.gridLayout.addWidget(self.lblFormat, 5, 0, 1, 1)
        self.cbFormat = QtGui.QComboBox(self.centralwidget)
        self.cbFormat.setMaximumSize(QtCore.QSize(100, 16777215))
        self.cbFormat.setObjectName(_fromUtf8("cbFormat"))
        self.cbFormat.addItem(_fromUtf8(""))
        self.cbFormat.addItem(_fromUtf8(""))
        self.cbFormat.addItem(_fromUtf8(""))
        self.cbFormat.addItem(_fromUtf8(""))
        self.cbFormat.addItem(_fromUtf8(""))
        self.gridLayout.addWidget(self.cbFormat, 6, 0, 1, 1)
        self.cmdKonvert = QtGui.QPushButton(self.centralwidget)
        self.cmdKonvert.setMaximumSize(QtCore.QSize(100, 16777215))
        self.cmdKonvert.setObjectName(_fromUtf8("cmdKonvert"))
        self.gridLayout.addWidget(self.cmdKonvert, 11, 0, 1, 1)
        self.txtAusgabe = QtGui.QLineEdit(self.centralwidget)
        self.txtAusgabe.setEnabled(False)
        self.txtAusgabe.setObjectName(_fromUtf8("txtAusgabe"))
        self.gridLayout.addWidget(self.txtAusgabe, 12, 0, 1, 1)
        self.cmdOeffnen2 = QtGui.QPushButton(self.centralwidget)
        self.cmdOeffnen2.setObjectName(_fromUtf8("cmdOeffnen2"))
        self.gridLayout.addWidget(self.cmdOeffnen2, 12, 1, 1, 1)
        self.lstFiles = QtGui.QListWidget(self.centralwidget)
        self.lstFiles.setObjectName(_fromUtf8("lstFiles"))
        self.gridLayout.addWidget(self.lstFiles, 9, 0, 1, 1)
        self.cmdAnwenden = QtGui.QPushButton(self.centralwidget)
        self.cmdAnwenden.setMaximumSize(QtCore.QSize(100, 16777215))
        self.cmdAnwenden.setObjectName(_fromUtf8("cmdAnwenden"))
        self.gridLayout.addWidget(self.cmdAnwenden, 7, 0, 1, 1)
        Mw.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(Mw)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 508, 20))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        Mw.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(Mw)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        Mw.setStatusBar(self.statusbar)

        self.retranslateUi(Mw)
        QtCore.QMetaObject.connectSlotsByName(Mw)

    def retranslateUi(self, Mw):
        Mw.setWindowTitle(QtGui.QApplication.translate("Mw", "vfa-converter", None, QtGui.QApplication.UnicodeUTF8))
        self.txtEingabe.setText(QtGui.QApplication.translate("Mw", "Eingabe-Datei", None, QtGui.QApplication.UnicodeUTF8))
        self.cmdOeffnen.setText(QtGui.QApplication.translate("Mw", "Hinzufügen", None, QtGui.QApplication.UnicodeUTF8))
        self.lblFormat.setText(QtGui.QApplication.translate("Mw", "Ausgabe Formart", None, QtGui.QApplication.UnicodeUTF8))
        self.cbFormat.setItemText(0, QtGui.QApplication.translate("Mw", "mp3", None, QtGui.QApplication.UnicodeUTF8))
        self.cbFormat.setItemText(1, QtGui.QApplication.translate("Mw", "aac", None, QtGui.QApplication.UnicodeUTF8))
        self.cbFormat.setItemText(2, QtGui.QApplication.translate("Mw", "wav", None, QtGui.QApplication.UnicodeUTF8))
        self.cbFormat.setItemText(3, QtGui.QApplication.translate("Mw", "ogg", None, QtGui.QApplication.UnicodeUTF8))
        self.cbFormat.setItemText(4, QtGui.QApplication.translate("Mw", "wma", None, QtGui.QApplication.UnicodeUTF8))
        self.cmdKonvert.setText(QtGui.QApplication.translate("Mw", "Konvertieren", None, QtGui.QApplication.UnicodeUTF8))
        self.txtAusgabe.setText(QtGui.QApplication.translate("Mw", "Ausgabe-Ordner", None, QtGui.QApplication.UnicodeUTF8))
        self.cmdOeffnen2.setText(QtGui.QApplication.translate("Mw", "Öffnen", None, QtGui.QApplication.UnicodeUTF8))
        self.cmdAnwenden.setText(QtGui.QApplication.translate("Mw", "Anwenden", None, QtGui.QApplication.UnicodeUTF8))

