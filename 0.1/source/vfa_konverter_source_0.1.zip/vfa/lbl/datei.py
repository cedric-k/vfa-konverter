class Datei():
	def __init__(self,name,pfad):
		self.format=0
		self.name=name
		self.pfad=pfad