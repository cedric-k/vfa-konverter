#! /usr/bin/python
# -*- coding: utf-8 -*-


import sys
sys.path.append('lbl')
import os
from PyQt4 import QtGui, QtCore, Qt
from ui import  Ui_Mw
import re
import datei



class StartQT4(QtGui.QMainWindow):
	
	def __init__(self, parent=None):
		QtGui.QWidget.__init__(self, parent)
		self.ui = Ui_Mw()
		self.ui.setupUi(self)
		self.dateien=[]
		self.ausgabe=None
		self.fd = QtGui.QFileDialog(self)
		QtCore.QObject.connect(self.ui.cmdKonvert,QtCore.SIGNAL("clicked()"), self.Start)
		QtCore.QObject.connect(self.ui.cmdOeffnen,QtCore.SIGNAL("clicked()"), self.Oeffnen)
		QtCore.QObject.connect(self.ui.cmdOeffnen2,QtCore.SIGNAL("clicked()"), self.Oeffnen2)
		QtCore.QObject.connect(self.ui.lstFiles,QtCore.SIGNAL("currentRowChanged(int)"), self.ItemGewaehlt)
		QtCore.QObject.connect(self.ui.cmdAnwenden,QtCore.SIGNAL("clicked()"), self.Anwenden)
		
		
	
	
	def Oeffnen(self):
		pfad=self.fd.getOpenFileName()
		for part in re.split("/",pfad):
			name=part
		name=re.split("\.",name)[0]
		self.dateien.append(datei.Datei(name,pfad))
		self.ui.lstFiles.addItem(pfad)
	
	def Oeffnen2(self):
		self.ausgabe=self.fd.getExistingDirectory()
		self.ui.txtAusgabe.setText(self.ausgabe)

		
	def ItemGewaehlt(self):
		self.ui.cbFormat.setCurrentIndex(int(self.dateien[self.ui.lstFiles.currentRow()].format))
	
	def Anwenden(self):
		self.dateien[self.ui.lstFiles.currentRow()].format=self.ui.cbFormat.currentIndex()
	
	def Start(self):
		self.threadKonv=Konvertieren(self.dateien,self.ausgabe,self.ui)
		self.threadKonv.start()
	
class Konvertieren(Qt.QThread):
	
	def __init__(self,dateien,ausgabe,ui):
		QtCore.QThread.__init__(self)
		self.dateien=dateien
		self.ausgabe=ausgabe
		self.ui=ui
		
	def run(self):
		for datei in self.dateien:
			if datei.format==0:
				format="mp3"
			elif datei.format==1:
				format="acc"
			elif datei.format==2:
				format="wav"
			elif datei.format==3:
				format="ogg"
			elif datei.format==4:
				format="wma"
			os.system(r'C://Programme/ffmpeg/bin/ffmpeg.exe -i "%s" "%s"'%(datei.pfad,self.ausgabe+"/"+datei.name+"."+format))
			
		
		
	
		
		
if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    myapp = StartQT4()
    myapp.show()
    sys.exit(app.exec_())





